package com.disciplinetrading.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class GenericResponse {
	private String message;
	private ResponseStatus status;
	private Object data;
	
}
