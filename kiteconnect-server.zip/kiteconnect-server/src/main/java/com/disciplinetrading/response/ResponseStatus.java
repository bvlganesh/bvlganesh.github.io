package com.disciplinetrading.response;

public enum ResponseStatus {
	SUCCESS, FAIL;
}
