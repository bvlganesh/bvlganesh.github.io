package com.disciplinetrading.algo4.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.disciplinetrading.account.Account;
import com.disciplinetrading.account.KiteConnectHolder;
import com.disciplinetrading.algo4.cron.CronConfiguration;
import com.disciplinetrading.algo4.dto.Algo4Tokens;
import com.disciplinetrading.algo4.model.OrderResponse;
import com.disciplinetrading.algo4.service.Algo4Service;
import com.disciplinetrading.response.GenericResponse;
import com.disciplinetrading.response.ResponseStatus;
import com.google.gson.Gson;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;

import lombok.extern.slf4j.Slf4j;

@RestController
//@SpringBootApplication
@Slf4j
@RequestMapping("/algo4")
public class Algo4Application {
	@Autowired
	Algo4Service a4s;
	
	@Autowired
	Gson gson;

	@Autowired
	KiteConnectHolder holder;
	
	@Autowired
	CronConfiguration cron;

	@RequestMapping(path = "/tokens", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse tokensOfthisMonth() {
		try {
			return GenericResponse.builder().data(a4s.tokensOfthisMonth(Calendar.getInstance().getTime())).build();
		} catch (JSONException | IOException e) {
			log.error("JSONException/IOException in tokensOfthisMonth:", e);
			return GenericResponse.builder().status(ResponseStatus.FAIL).message(e.getMessage()).build();
		} catch (KiteException e) {
			log.error("tokensOfthisMonth:KiteConnection Exception:", e);
			return GenericResponse.builder().status(ResponseStatus.FAIL).message(e.getMessage()).build();
		}
	}

	@RequestMapping(path = "/activeaccount", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse currentUser() {
		return GenericResponse.builder().data(holder.currentAccount()).build();
	}

	@SuppressWarnings("static-access")
	@GetMapping(path = "/accounts", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse configs() {
		return GenericResponse.builder().data(holder.getAccounts()).build();
	}

	@RequestMapping(path = "/order/{type}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse placeOrder(@PathVariable(value = "type") String type, @RequestBody Algo4Tokens tokens) {
		try {
			Optional<List<OrderResponse>> orderId = a4s.placeOrder(tokens, type);
			if (orderId.isPresent()) {
				return GenericResponse.builder().status(ResponseStatus.SUCCESS).data(orderId).build();
			} else {
				return GenericResponse.builder().status(ResponseStatus.FAIL).message("Order place failed").build();
			}
		} catch (JSONException | IOException e) {
			log.error("JSONException/IOException in placeOrder:", e);
//			throw new RuntimeException(e.getMessage());
			return GenericResponse.builder().status(ResponseStatus.FAIL).message(e.getMessage()).build();
		} catch (KiteException e) {
			log.error("KiteConnection Exception:", e);
//			throw new RuntimeException(e.getMessage());
			return GenericResponse.builder().status(ResponseStatus.FAIL).message(e.getMessage()).build();
		}
	}

	@PostMapping(value = "/account/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse addAccount(@RequestBody Account account) {

		holder.addAccount(account);
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).build();
	}

	@PostMapping(value = "/account/connect", consumes = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse markActive(@Valid @RequestBody Account account) throws IOException {
		if (StringUtils.isEmpty(account.getRequestToken())) {
//			throw new RuntimeException("RequestToken value is mandatory");
			return GenericResponse.builder().status(ResponseStatus.FAIL).message("RequestToken value is mandatory")
					.build();
		}

		try {
			holder.initiateSession(account);
			holder.getAccounts().put(account.getId(), account);
//			a4s.fetchPreviousClose(holder, account);
		} catch (KiteException e) {
			log.error("initiateSession failed:", e);
//			throw new RuntimeException("Session creation failed:" + e.getMessage());
			return GenericResponse.builder().status(ResponseStatus.FAIL)
					.message("Session creation failed:" + e.getMessage()).build();
		}

//		HashMap<String, String> response = new HashMap<>();
//		response.put("response", ResponseStatus.SUCCESS);
//		return new ResponseEntity<Object>(response, HttpStatus.OK);
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).build();

	}

	@GetMapping(path = "/accounts/export", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse export() {
		return GenericResponse.builder().data(holder.getAccounts().values()).status(ResponseStatus.SUCCESS).build();
	}

	@GetMapping(path = "/config", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse configuration() {
		List<HashMap<String, String>> configList = new ArrayList<>();
		HashMap<String, String> configuration = new HashMap<>();
		configuration.put("name", "Nifty");
		configuration.put("key", "NIFTY");
		configList.add(configuration);
		configuration = new HashMap<>();
		configuration.put("name", "Bank Nifty");
		configuration.put("key", "BANKNIFTY");
		configList.add(configuration);

		return GenericResponse.builder().status(ResponseStatus.SUCCESS).data(configList).build();
	}
	@PostMapping(path = "/start")
	public GenericResponse startTracking(@Valid @RequestBody Account acnt) throws IOException, KiteException {
//		Account acnt = holder.getAccounts().get("RK0594");
//		acnt.setRequestToken("qbIzkes6SB6EaZesoQxWVVBgv3ugNMwR");
//		acnt.setTokenGroup("NIFTY");
//		acnt.setPingInterval(2);
//		holder.initiateSession(acnt);
		cron.triggerTracking();
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).build();
	}
	
	@GetMapping(path = "/stop")
	public GenericResponse stopTracking() throws IOException, KiteException {
//		System.out.println(gson.toJson(cron.getAllTicks()));
		
		cron.disconnectAndTrack();
		
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).build();
	}
	
	@GetMapping(path = "/shutdown")
	public GenericResponse shutdownjobs() {
		log.info("Received shutdown request");
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).data(cron.forceStop()).build();
	}
	
//	@GetMapping(path = "/name/{token}")
//	public GenericResponse tokenInfo(@PathParam("token") String tokenSymbol) {
//		log.info("Looking for tokenInfo of:{}", tokenSymbol);
//		return GenericResponse.builder().status(ResponseStatus.SUCCESS).data(cron.tokenInfo(tokenSymbol)).build();
//	}
	@GetMapping(path="/initiate")
	public GenericResponse initiateReqToken() {
		return GenericResponse.builder().status(ResponseStatus.SUCCESS).data(cron.createSession()).build();
	}
}
