package com.disciplinetrading.algo4.cron.jobs;

import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.KiteConnectHolder;
import com.google.gson.Gson;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public abstract class ParentJob implements Runnable  {
	protected KiteConnectHolder holder;
	protected DataVOs data;
	protected static final Gson gson = new Gson();
}
