package com.disciplinetrading.algo4.service;

import java.io.IOException;
import java.text.DateFormatSymbols;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.util.StopWatch.TaskInfo;

import com.disciplinetrading.account.Account;
import com.disciplinetrading.account.AllInstruments;
import com.disciplinetrading.account.KiteConnectHolder;
import com.disciplinetrading.algo4.dto.Algo4Token;
import com.disciplinetrading.algo4.dto.Algo4Tokens;
import com.disciplinetrading.algo4.model.OrderResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;
import com.zerodhatech.kiteconnect.utils.Constants;
import com.zerodhatech.models.Instrument;
import com.zerodhatech.models.OHLCQuote;
import com.zerodhatech.models.Order;
import com.zerodhatech.models.OrderParams;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Algo4Service {
	private static DateFormatSymbols dateSymbols = new DateFormatSymbols();
	private static final Double percValue = 1.0d;
	@Autowired
	KiteConnectHolder holder;

//	@Autowired
//	Optional<Account> currentAccount;

//	private static final Logger log = LoggerFactory.getLogger(Algo4Service.class);

	public Map<String, Algo4Tokens> tokensOfthisMonth(Date currentDate)
			throws JSONException, IOException, KiteException {
//		Date today = Calendar.getInstance().getTime();
		Double previousDayClose = fetchPreviousDayClose(currentDate);
		List<Double> limits = computeLimits(previousDayClose);
		Set<Instrument> filtered = new HashSet<>();
//		Integer currentYear = currentYear(currentDate);
//		String currentMonth = currentMonth(currentDate);
//		Integer nearestThursday = nextThursdayDate(currentDate);
//		String lookupPattern = getCurrentAccount().get().getTokenGroup().toUpperCase() + currentYear
//				+ currentMonth.charAt(0) + nearestThursday.toString();
		LocalDate ld = nextThursdayDate(currentDate);
		String nearestThursday = String.format("%02d", ld.getDayOfMonth());
		Integer currentYear = ld.getYear() - 2000;
		Integer currentMonthNbr = ld.getMonthValue();
		String lastThursdayOfMonth = lastThursdayOfMonth(currentDate).toString();
		
		String lookupPattern =getCurrentAccount().get().getTokenGroup().toUpperCase() + currentYear.toString() + currentMonthNbr.toString() + nearestThursday.toString();
//		filtered = AllInstruments.matchingInstruments("NFO", limits.get(1), limits.get(0), lookupPattern.toUpperCase());
//		if (CollectionUtils.isEmpty(filtered)) {
//			// may be usecase of month end like Oct 31, 2019
//			String monthendPattern = getCurrentAccount().get().getTokenGroup().toUpperCase() + currentYear
//					+ currentMonth;
//			filtered = AllInstruments.matchingInstruments("NFO", limits.get(1), limits.get(0),
//					monthendPattern.toUpperCase());
//		}
		if(nearestThursday.equalsIgnoreCase(lastThursdayOfMonth)) {
			//incase of last thursday token will be NIFTY20feb12100CE instead of NIFTY2020512100CE
			lookupPattern = getCurrentAccount().get().getTokenGroup().toUpperCase() + currentYear.toString() + dateSymbols.getShortMonths()[currentMonthNbr-1].toUpperCase();//+nearestThursday.toString();
		}
		filtered = AllInstruments.matchingInstruments("NFO", limits.get(1), limits.get(0), lookupPattern.toUpperCase());
		final Algo4Tokens tokens = new Algo4Tokens();
		filtered.forEach(eachToken -> {
//			String[] tokenInfo = eachToken.split(",");
			Algo4Token newToken = new Algo4Token();
			newToken.setId(eachToken.getInstrument_token());
			newToken.setSymbol(eachToken.getTradingsymbol());
//			newToken.setStrikePrice(Long.valueOf(tokenInfo[2].replaceAll(lookupPattern, "").replace("PE", "").replace("CE", "")));
//			Long strikePrice = new BigDecimal(tokenInfo[6]).longValue();
			newToken.setStrikePrice(Double.valueOf(eachToken.getStrike()));
			newToken.setQuantity(eachToken.getLot_size());
//			if(strikePrice.doubleValue() >= limits.get(0) && strikePrice.doubleValue() <= limits.get(1)) {
//				tokens.addToken(newToken);
//			}
			tokens.addToken(newToken);
		});

		return classifyCallsPuts(tokens);
	}

	// compute 1%(uses variable percValue) above and below and send back in [0,1]
	// position
	private List<Double> computeLimits(Double previousDayClose) {
		List<Double> limits = new ArrayList<>();
		limits.add(Double.valueOf((previousDayClose * (1 - (percValue / 100)))));
		limits.add(Double.valueOf((previousDayClose * (1 + (percValue / 100)))));
		return limits;
	}

	private Double fetchPreviousDayClose(Date currentDate) throws JSONException, IOException, KiteException {
		String tokenSymbol = consutructToken(currentDate);
		Long tokenId = AllInstruments.bySymbol(tokenSymbol).getInstrument_token();
		log.info("Fetching OHLC for token:{}, symbol:{}", tokenId, tokenSymbol);
		OHLCQuote quote = holder.getKiteSdk().getOHLC(new String[] { tokenId.toString() }).get(tokenId.toString());
		return quote.ohlc.close;
	}

	// consutructs token like NIFTY19NOVFUT, BANKNIFTY19DECFUT
	private String consutructToken(Date currentDate) {

		String tokenGroup = holder.currentAccount().getTokenGroup().toUpperCase();

		return tokenGroup + currentYear(currentDate) + currentMonth(currentDate) + "FUT";
	}

	// separate calls and puts into 2 lists based on Symbol
	private Map<String, Algo4Tokens> classifyCallsPuts(Algo4Tokens tokens) {
		Map<String, Algo4Tokens> dataMap = new HashMap<>();
		Algo4Tokens callTokens = new Algo4Tokens();
		Algo4Tokens putTokens = new Algo4Tokens();

		tokens.getTokens().stream().forEach(token -> {
			if (token.getSymbol().endsWith("CE")) {
				callTokens.addToken(token);
			} else if (token.getSymbol().endsWith("PE")) {
				putTokens.addToken(token);
			}
		});
		dataMap.put("calls", callTokens);
		dataMap.put("puts", putTokens);

		return dataMap;
	}

	@SuppressWarnings("deprecation")
	private static String currentMonth(Date today2) {
		int month = today2.getMonth();
		return dateSymbols.getShortMonths()[month].toUpperCase();
	}

	@SuppressWarnings("deprecation")
	private static Integer currentYear(Date today) {
		return today.getYear() + 1900 - 2000;
	}

//	private Integer nextThursdayDate(Date today2) {
//		LocalDate ld = today2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//		return ld.with(TemporalAdjusters.nextOrSame(DayOfWeek.THURSDAY)).getDayOfMonth();
//	}

	public Optional<List<OrderResponse>> placeOrder(Algo4Tokens tokens, String orderType)
			throws JSONException, IOException, KiteException {
		StopWatch sw = new StopWatch();
		try {
			List<OrderResponse> orderResponse = new ArrayList<>();
			List<String> currentOrderIds = new ArrayList<>();
			sw.start("placeOrder");
			log.info("Placing order:{}", new ObjectMapper().writeValueAsString(tokens));
//			for (Algo4Token token : tokens.getTokens()) {
			tokens.getTokens().parallelStream().forEach(token -> {
				OrderParams orderParams = buildOrderParams(token, orderType.toUpperCase());
				try {
					Order order = holder.getKiteSdk().placeOrder(orderParams, Constants.VARIETY_REGULAR);
					currentOrderIds.add(order.orderId);
				} catch (JSONException | IOException | KiteException e) {
					throw new RuntimeException(e);
				}
//				orderIds.add(order.orderId);
			});
//			log.info("Timetaken to place {} orders:{}", tokens.getTokens().size(), sw.getTotalTimeMillis());
			sw.stop();
			sw.start("allOrders");
			List<Order> allOrders = holder.getKiteSdk().getOrders();
			sw.stop();
			log.info("Total Orders:{}. CurrentOrders:{}", allOrders.size(), currentOrderIds.size());
			allOrders.parallelStream()
			.filter(order -> currentOrderIds.contains(order.orderId))
			.forEach(currOrder -> {
				orderResponse.add(new OrderResponse(currOrder));
			});
//			System.err.println(currentOrders.get(0).status);
			return Optional.of(orderResponse);
		} catch (JsonProcessingException e) {
			log.error("Failed to placeOrder:", e);
		} finally {
			if (sw.isRunning())
				sw.stop();
//			log.info("placeOrder total time:" + sw.shortSummary());
//			log.info(sw.prettyPrint());
//			log.info(".." + sw.getTaskInfo()[0].getTimeSeconds());
			for (TaskInfo task : sw.getTaskInfo()) {
				log.info("Time taken(ms) for {}:{}", task.getTaskName(), task.getTimeMillis());
			}
		}
		return Optional.empty();
	}

	private OrderParams buildOrderParams(Algo4Token token, String orderType) {

		OrderParams orderParams = new OrderParams();
		orderParams.quantity = token.getQuantity();
		orderParams.orderType = Constants.ORDER_TYPE_MARKET;
		orderParams.tradingsymbol = token.getSymbol();
		orderParams.product = Constants.PRODUCT_MIS;
		orderParams.exchange = Constants.EXCHANGE_NFO;
		orderParams.transactionType = orderType;// Constants.TRANSACTION_TYPE_BUY;// SELL
		orderParams.validity = Constants.VALIDITY_DAY;

		orderParams.disclosedQuantity = token.getQuantity();

		orderParams.tag = "MyTag123";

		return orderParams;

	}

	private Optional<Account> getCurrentAccount() {
		if (holder.getKiteSdk() == null) {
			return Optional.empty();
		}
		return Optional.of(holder.getAccounts().get(holder.getKiteSdk().getUserId()));
	}
	
	private LocalDate nextThursdayDate(Date today2) {
		LocalDate ld = today2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return ld.with(TemporalAdjusters.nextOrSame(DayOfWeek.THURSDAY));
	}
	
	private Integer lastThursdayOfMonth(Date today) {
		LocalDate ld = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return ld.with(TemporalAdjusters.lastInMonth(DayOfWeek.THURSDAY)).getDayOfMonth();
	}

}
