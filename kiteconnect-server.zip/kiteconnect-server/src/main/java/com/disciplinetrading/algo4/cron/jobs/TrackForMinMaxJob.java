package com.disciplinetrading.algo4.cron.jobs;

import java.io.IOException;
import java.util.Date;

import org.json.JSONException;
import org.springframework.util.StopWatch;

import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.KiteConnectHolder;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;
import com.zerodhatech.models.LTPQuote;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TrackForMinMaxJob extends ParentJob {
	public TrackForMinMaxJob(KiteConnectHolder holder, DataVOs data) {
		super(holder, data);
	}
	private String accountId() {
		return holder.currentAccount().getId();
	}
	@Override
	public void run() {
//		log.warn("TrackForMinMaxJob triggered:{}", new Date());
//		holder.fetchLiveData(tokenMap.get(currentAcnt.getTokenGroup().toUpperCase()), allTicks);
		
		try {
			Long token = holder.getKiteTokenId();
			String id = Thread.currentThread().getName() + token;
			StopWatch sw = new StopWatch(id);
//			log.info("trying LTP of token:{}", token);
//			consumer.accept(holder.getKiteSdk().getLTP(new String[] { token }));// .get(token).lastPrice;
			sw.start();
			LTPQuote quote = holder.getKiteSdk().getLTP(new String[] { token.toString() }).get(token.toString());
			sw.stop();
			if(quote != null) {
				
				log.info("QuoteReceived for token:{}, value:{} in:{}", token, quote.lastPrice, sw.getTotalTimeMillis());
				data.addLTPQuote(accountId(), quote);
			} else {
				
				log.warn("Quote is null for token:{}", token);
			}
			

		} catch (JSONException | IOException | KiteException e) {
			log.error("MinMaxJob:run failed:", e);
		}
	}

}
