package com.disciplinetrading.algo4.dto;

import java.util.HashSet;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import lombok.Getter;
import lombok.Setter;

public class Algo4Tokens {
	@Getter
	@Setter
	private Set<Algo4Token> tokens;
	
	public void addToken(Algo4Token token) {
		if(CollectionUtils.isEmpty(tokens)) {
			tokens = new HashSet<Algo4Token>();
		}
		tokens.add(token);
	}
}
