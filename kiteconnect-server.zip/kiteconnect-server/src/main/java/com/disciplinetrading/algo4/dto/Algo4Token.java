package com.disciplinetrading.algo4.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Algo4Token {
	private Long id;
	private String symbol;
	private Double strikePrice;
	private Integer quantity;
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		Algo4Token otherToken = (Algo4Token) obj;
		if(this.id == null || otherToken.getId() == null) {
			return false;
		}
		if(this.symbol == null || otherToken.getSymbol() == null) {
			return false;
		}
		
		if(this.id.equals(otherToken.getId()) && this.symbol.equalsIgnoreCase(otherToken.getSymbol())) {
			return true;
		} else {
			return false;
		}
	}
}
