package com.disciplinetrading.algo4.cron;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

import javax.annotation.PostConstruct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import com.disciplinetrading.account.Account;
import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.KiteConnectHolder;
import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.algo4.cron.jobs.TrackForMinMaxJob;
import com.disciplinetrading.algo4.cron.jobs.TradeWithMinMaxJob;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@ConditionalOnProperty(
	    value="algoValue", 
	    havingValue = "algo4", 
	    matchIfMissing = false)
public class CronConfiguration {
	
	WebDriver driver ;
	
	@Autowired
	KiteConnectHolder holder;

	private final DataVOs data = new DataVOs();

	@Value("${algo4.cron.pingInterval}")
	String pingInterval;

	@Autowired
	TaskScheduler taskScheduler;

	private Map<String, ScheduledFuture<?>> schedulerMap = new HashMap<>();

	@Autowired
	Environment env;

	@PostConstruct
	public void initialize() {
		
		// incase of local testing accountId will be passed as param
		String accountId = env.getProperty("accountId");// passed as jvm arg for testing
		String isTest = env.getProperty("isTest");
		if (!StringUtils.isEmpty(accountId) && !"TRUE".equalsIgnoreCase(isTest)) {
			String reqToken = env.getProperty("reqToken");// passed as jvm arg for testing
			try {
				log.info("Mocking Account with id:{}", accountId);
				Account curAcnt = holder.getAccounts().get(accountId);
				curAcnt.setRequestToken(reqToken);
				curAcnt.setTokenGroup(env.getProperty("tokenGroup"));
				holder.initiateSession(curAcnt);
				// below will ensure currentAccount() method will return this account
//				holder.getKiteSdk().setUserId(curAcnt.getId());
				triggerTracking();
				// this will ensure disconnect will be called after some time(passed as jvm
				// args)
				log.info("Going into sleep");
				Thread.sleep(Long.valueOf(env.getProperty("disconnectAfter")));
				disconnectAndTrack();
			} catch (IOException | KiteException | NumberFormatException | InterruptedException e) {
				log.error("initialization failed:", e);
			}
		} else {
//			loadDriver();
		}
	}

	private void loadDriver() {
		if(System.getProperty("os.name").toLowerCase().contains("windows")) {
			System.setProperty("webdriver.gecko.driver", "geckodriver-win.exe");
		} else {
			System.setProperty("webdriver.gecko.driver", "geckodriver");
		}
		FirefoxOptions options = new FirefoxOptions();
		options.setHeadless(true);
		driver = new FirefoxDriver(options);
		
	}

	//2nd jan - BANKNIFTY2010228100CE/11709442
	//23 jan -  BANKNIFTY2012328100CE/8964866
	private void startJobForFindingMinMax(DataVOs data) {
		// start fetching LPT/LiveData at 1minute interval starting next 0th second
		// at 9.30AM another schedule job will kick-in and will kill this job
		ScheduledFuture<?> sf = taskScheduler.schedule(new TrackForMinMaxJob(holder, data), new CronTrigger(pingInterval));
		schedulerMap.put("TrackForMinMaxJob", sf);
	}
	
	@Scheduled(cron = "${algo4.cron.createSession}", zone = "IST") // every Thursday at 9:15 AM
	public String createSession() {
		StopWatch sw = new StopWatch();
		try {
			sw.start();
			loadDriver();
			Account acc = holder.getAccounts().get(env.getProperty("account.id"));
			
	        driver.get("https://kite.trade/connect/login?api_key="+acc.getApiKey()+"&v=3");
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[1]/input")).sendKeys(acc.getId());
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[2]/input")).sendKeys(env.getProperty("account.pwd"));
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[4]/button")).click();
			Thread.sleep(3000);
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[2]/div/input")).sendKeys(env.getProperty("account.pin"));
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[3]/button")).click();
			Thread.sleep(3000);
	        String url = driver.getCurrentUrl();
	        log.info("Final URL received:{}", url);
	        if(url.contains("request_token=")) {
	        	String reqTokenExtracted = url.split("request_token=")[1].split("&")[0];
	        	log.info("ReqToken:"+ reqTokenExtracted);
	        	acc.setRequestToken(reqTokenExtracted);
	        }
	        driver.close();
	        holder.initiateSession(acc);
		} catch(Exception | KiteException e) {
			log.error("createSession failed:", e);
			return "failed";
		} finally {
			sw.stop();
			log.info("TimeTaken for createSession:{} ms", sw.getTotalTimeMillis());
		}
		return "Success";
	}

	/**
	 * starts at 9:15 in morning. validates if requesttoken available. Creates
	 * session and starts tracking.
	 */
	@Scheduled(cron = "${algo4.cron.starttracking}", zone = "IST") // every Thursday at 9:15 AM
	public void triggerTracking() throws IOException, KiteException {
		// only for sake of testing
//		boolean initiated = isTestEnv();

		Account currentAcnt = holder.currentAccount();
		if (currentAcnt != null) {
			if (holder.getKiteSdk() != null) {
				// incase of local running, this will not get executed
				holder.initiateSession(currentAcnt);
			}
			startJobForFindingMinMax(data);
		} else {
			throw new RuntimeException("No Account is currently active");
		}
	}

	@Scheduled(cron = "${algo4.cron.stoptracking}", zone = "IST") // every Thursday at 9:30 AM
	public void disconnectAndTrack() throws IOException, KiteException {
		log.info("CronConfiguration.disConnect()");
		Account currentAcnt = holder.currentAccount();
//		log.info("data:", new Gson().toJson(data));
		if (currentAcnt != null && !StringUtils.isEmpty(currentAcnt.getRequestToken())) {
//			holder.unsubscribeAndDisc(tokenMap.get(currentAcnt.getTokenGroup().toUpperCase()));
			if (schedulerMap.get("TrackForMinMaxJob") != null) {
				log.info("cancelling Scheduler: TrackForMinMaxJob");
				schedulerMap.get("TrackForMinMaxJob").cancel(false);
			}
			log.info("Scheduling TradeWithMinMaxJob task");
			MinMax minmax = data.computeMinMaxFromLTPQuotes(holder.currentAccount().getId(), holder.getKiteTokenId(), true, holder.getStepValue());
			log.info("MinMax computed:{}", minmax);
			ScheduledFuture<?> sf = taskScheduler.schedule(new TradeWithMinMaxJob(holder, data, minmax), new CronTrigger(pingInterval));
			schedulerMap.put("TradeWithMinMaxJob", sf);
//			holder.fetchLiveData(token, allTicks);
		} else {
			throw new RuntimeException("No Account is currently active");
		}

	}
	
	public String forceStop() {
		StringBuffer response = new StringBuffer();
		try {
			response.append("Jobs to cancel:" + schedulerMap.size() + ".\n");
			for(String key : schedulerMap.keySet()) {
				log.info("Trying to cancel job:{}" , key );
				schedulerMap.get(key).cancel(false);
				response.append("Cancelled:" + key + "\n");
				log.info("Successfully cancelled job:{}" , key );
			}
			
		} catch(Exception e) {
			response.append("Failed due to:" + e.getMessage());
		}
		return response.toString();
	}

//	public Object tokenInfo(String tokenSymbol) {
//		try {
//			holder.initiateSession(holder.getAccounts().get("RK0594"));
//			return holder.getKiteSdk().getInstruments().stream().filter(instrument -> tokenSymbol.equalsIgnoreCase(instrument.tradingsymbol)).findFirst().get();
//		} catch (JSONException | IOException | KiteException e) {
//			log.error("Failed to find matching tokenInfo:", e);
//		}
//		return new Instrument();
//	}
	
}
