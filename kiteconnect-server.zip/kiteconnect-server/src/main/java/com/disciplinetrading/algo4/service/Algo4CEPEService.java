package com.disciplinetrading.algo4.service;

public class Algo4CEPEService {
	public void processTick() {
		
	}
}
