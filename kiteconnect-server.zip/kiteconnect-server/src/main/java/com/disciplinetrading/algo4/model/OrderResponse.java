package com.disciplinetrading.algo4.model;

import com.zerodhatech.models.Order;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderResponse {
	private Long orderId;
	private String status;
	private String type;
	public OrderResponse(Order order) {
		this.orderId = Long.valueOf(order.orderId);
		this.status = order.status;
		this.type = order.transactionType;
	}
}
