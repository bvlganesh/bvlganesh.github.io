package com.disciplinetrading.algo5.cron.jobs;

import java.io.IOException;
import java.text.DateFormatSymbols;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;

import org.json.JSONException;

import com.disciplinetrading.account.AllInstruments;
import com.disciplinetrading.account.DataVO;
import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.KiteConnectHolder;
import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.account.OrderConfig;
import com.disciplinetrading.account.OrderVO;
import com.disciplinetrading.algo4.cron.jobs.ParentJob;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;
import com.zerodhatech.kiteconnect.utils.Constants;
import com.zerodhatech.models.Instrument;
import com.zerodhatech.models.LTPQuote;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class TrackForNextMatch extends ParentJob{

	
	@Getter(value = AccessLevel.PUBLIC)
	private MinMax minmax;
	private static DateFormatSymbols dateSymbols = new DateFormatSymbols();
	
	public TrackForNextMatch(KiteConnectHolder holder, DataVOs data, MinMax minmax) {
		super(holder, data);
		this.minmax = minmax;
	}

	@Override
	public void run() {
		
		try {
			
			String id = holder.currentAccount().getId();
			DataVO vo = data.getData(id);
			
			if(vo.isOrderPlaced()) {
				
			} else {
				Long token = holder.getKiteTokenId();
				LTPQuote quote = holder.getKiteSdk().getLTP(new String[] { token.toString() }).get(token.toString());
				evaluateParentOrder(quote, holder.currentAccount().getId(), holder.currentAccount().getTokenGroup(), holder.getStepValue());
			}
			
			
		} catch (JSONException | IOException | KiteException e) {
			log.error("Exception in TradeWithMinMaxJob:", e);
		}
	}

	private boolean isInLimits(double lastPrice, Double min) {
		return min.longValue() - 5 <= lastPrice && min.longValue() + 5 > lastPrice;
	}
	public void evaluateParentOrder(LTPQuote quote, String id, String tokenGroup, Long stepValue) {
//		String tokenGroup = holder.currentAccount().getTokenGroup();
		DataVO vo = data.getData(id);
//		Long stepValue = holder.getStepValue();
		if (isInLimits(quote.lastPrice, minmax.getMin())) {
//		if(quote.lastPrice < minmax.getMin()) {
			//if market is going down, do not touch puts, just counter calls
			log.info("Found a LTP({}) near to min({})", quote.lastPrice, minmax.getMin());
			placeOrderWithValue(minmax.getMin().longValue(), vo, tokenGroup, "CE", true);
			
				//this is for first order
			log.info("Placing the first PE order for < min scenario at {}", minmax.getMin());
			placeOrderWithValue(minmax.getMin().longValue(), vo, tokenGroup, "PE", true);
			updateMinMax(minmax.getMin(), stepValue);
			vo.setOrderPlaced(true);
			orderSummary(data.getData(id));
		} else 
//			if (quote.lastPrice > minmax.getMax()) {
			if(isInLimits(quote.lastPrice, minmax.getMax())) {
				//if market is going up, do not touch calls, just counter puts
			log.info("Found a LTP({}) near to max({})", quote.lastPrice, minmax.getMax());
			
			placeOrderWithValue(minmax.getMax().longValue(), vo, tokenGroup, "PE", true);
			//this is for first order
			placeOrderWithValue(minmax.getMax().longValue(), vo, tokenGroup, "CE", true);
//				placeOrderWithValue(minmax.getMax().longValue(), vo, tokenGroup, "PE", true);
			updateMinMax(minmax.getMax(), stepValue);
			vo.setOrderPlaced(true);
			orderSummary(data.getData(id));
		} else {
			log.info("Parent LTP({}) is not within limits for min({}) or max({})", quote.lastPrice, minmax.getMin(), minmax.getMax());
		}
		

	}
	private void updateMinMax(double currentTradePrice, Long stepValue) {
		double newmin = currentTradePrice - stepValue;
		double newmax = currentTradePrice + stepValue;
		log.info("Updating minmax values. Current min:{}, max:{}. New min:{}, max:{}", minmax.getMin(), minmax.getMax(), newmin, newmax);
		minmax = new MinMax(newmin, newmax);		
	}

	private void orderSummary(DataVO data) {
		if (data != null) {
			data.printOrders();
		} else {
			log.info("No data associated with active account yet");
		}

	}
	//type is CE or PE
	private void placeOrderWithValue(long value, DataVO vo, String tokenGroup, String optionType, boolean isSell) {

		String timeWithGroup = buildTokenSymbol(tokenGroup);
		OrderConfig ceOrder = placeSingleOrder(timeWithGroup, String.valueOf(value), optionType, isSell);//(timePrefix, type, value.toString(), tokenGroup);
		vo.addOrder(ceOrder);
	}
	//orderType is SELL or BUY
	//type is CE/PE
	private OrderConfig placeSingleOrder( String timeWithGroup, String value, String optionsType, boolean isSell) {
		String tokenSymbol =  timeWithGroup + value.toString() + optionsType;
		Instrument ce = AllInstruments.bySymbol(tokenSymbol);
		OrderConfig ceShortSellOrder = buildOrderParams(
				OrderVO.builder().quantity(ce.getLot_size()).symbol(ce.tradingsymbol).price(ce.strike)
						.type(isSell ? Constants.TRANSACTION_TYPE_SELL : Constants.TRANSACTION_TYPE_BUY ).tokenId(ce.getInstrument_token()).build());
		placeOrder(ceShortSellOrder);
		return ceShortSellOrder;
		
	}

	private void placeOrder(OrderConfig order) {
		try {
			log.info("Placing order:{}", gson.toJson(order));
//			holder.getKiteSdk().placeOrder(order, Constants.VARIETY_REGULAR);

		} catch (JSONException   e) {
			log.error("Exception in placeOrder:", e);
		}
	}

	private String buildTokenSymbol(String tokenGroup) {
//		Date currentDate = Date.from(Instant.now().plus(5, ChronoUnit.DAYS));
		Date currentDate = Date.from(Instant.now());
//		Integer currentYear = currentYear(currentDate);
//		Integer currentMonthNbr = currentMonthNbr(currentDate);
		LocalDate ld = nextThursdayDate(currentDate);
		String nearestThursday = String.format("%02d", ld.getDayOfMonth());
		Integer currentYear = ld.getYear() - 2000;
		Integer currentMonthNbr = ld.getMonthValue();
		String lastThursdayOfMonth = lastThursdayOfMonth(currentDate).toString();
		
		String lookupPattern = currentYear.toString() + currentMonthNbr.toString() + nearestThursday.toString();
		if(nearestThursday.equalsIgnoreCase(lastThursdayOfMonth)) {
			//incase of last thursday token will be NIFTY20feb12100CE instead of NIFTY2020512100CE
			lookupPattern = currentYear.toString() + dateSymbols.getShortMonths()[currentMonthNbr-1].toUpperCase();//+nearestThursday.toString();
		}
		return tokenGroup + lookupPattern;
	}

	private LocalDate nextThursdayDate(Date today2) {
		LocalDate ld = today2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return ld.with(TemporalAdjusters.nextOrSame(DayOfWeek.THURSDAY));
	}
	
	private Integer lastThursdayOfMonth(Date today) {
		LocalDate ld = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return ld.with(TemporalAdjusters.lastInMonth(DayOfWeek.THURSDAY)).getDayOfMonth();
	}

	// gives 1 for Jan, 6 for June
//	private static Integer currentMonthNbr(Date today2) {
//		LocalDate localDate = today2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//		return localDate.getMonthValue();
//	}
//
//	@SuppressWarnings("deprecation")
//	private static Integer currentYear(Date today) {
//		return today.getYear() + 1900 - 2000;
//	}

	

	private OrderConfig buildOrderParams(OrderVO orderVo) {

		OrderConfig orderParams = new OrderConfig();
		orderParams.quantity = orderVo.getQuantity();
		orderParams.orderType = orderVo.getOrderType();
		orderParams.tradingsymbol = orderVo.getSymbol();
		orderParams.product = orderVo.getProduct();
		orderParams.exchange = orderVo.getExchange();
		orderParams.transactionType = orderVo.getType();// Constants.TRANSACTION_TYPE_BUY;// SELL
		orderParams.validity = orderVo.getValidity();
		orderParams.price = Double.parseDouble(orderVo.getPrice());// read dynamic value-not needed for market order 
		 
		orderParams.disclosedQuantity = orderVo.getQuantity();

		orderParams.tag = "MyTag123";
		orderParams.setTokenId(orderVo.getTokenId());
		return orderParams;

	}

}
