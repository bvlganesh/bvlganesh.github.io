package com.disciplinetrading.algo5.cron;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.util.StringUtils;

import com.disciplinetrading.account.Account;
import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.KiteConnectHolder;
import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.algo4.cron.jobs.TrackForMinMaxJob;
import com.disciplinetrading.algo5.cron.jobs.TrackForNextMatch;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@ConditionalOnProperty(
	    value="algoValue", 
	    havingValue = "algo5", 
	    matchIfMissing = false)
public class CronConfiguration {
	@Autowired
	KiteConnectHolder holder;

	private final DataVOs data = new DataVOs();

	@Value("${algo5.cron.pingInterval}")
	String pingInterval;

	@Autowired
	TaskScheduler taskScheduler;

	private Map<String, ScheduledFuture<?>> schedulerMap = new HashMap<>();

	@Autowired
	Environment env;
	
	@Scheduled(cron = "${algo5.cron.starttracking}", zone = "IST") // every Thursday at 9:15 AM
	public void triggerTracking() throws IOException, KiteException {
		Account currentAcnt = holder.currentAccount();
		if (currentAcnt != null) {
			if (holder.getKiteSdk() != null) {
				// incase of local running, this will not get executed
				holder.initiateSession(currentAcnt);
			}
			startJobForFindingMinMax(data);
		} else {
			throw new RuntimeException("No Account is currently active");
		}
	}
	
	private void startJobForFindingMinMax(DataVOs data) {
		// start fetching LPT/LiveData at 1minute interval starting next 0th second
		// at 9.30AM another schedule job will kick-in and will kill this job
		ScheduledFuture<?> sf = taskScheduler.schedule(new TrackForMinMaxJob(holder, data), new CronTrigger(pingInterval));
		schedulerMap.put("TrackForMinMaxJob", sf);
	}
	
	@Scheduled(cron = "${algo5.cron.stoptracking}", zone = "IST") // every Thursday at 9:30 AM
	public void disconnectAndTrack() throws IOException, KiteException {
		log.info("CronConfiguration.disConnect()");
		Account currentAcnt = holder.currentAccount();
//		log.info("data:", new Gson().toJson(data));
		if (currentAcnt != null && !StringUtils.isEmpty(currentAcnt.getRequestToken())) {
//			holder.unsubscribeAndDisc(tokenMap.get(currentAcnt.getTokenGroup().toUpperCase()));
			if (schedulerMap.get("TrackForMinMaxJob") != null) {
				log.info("cancelling Scheduler: TrackForMinMaxJob");
				schedulerMap.get("TrackForMinMaxJob").cancel(false);
			}
			log.info("Scheduling TradeWithMinMaxJob task");
			MinMax minmax = data.computeMinMaxFromLTPQuotes(holder.currentAccount().getId(), holder.getKiteTokenId(), true, holder.getStepValue());
			log.info("MinMax computed:{}", minmax);
			ScheduledFuture<?> sf = taskScheduler.schedule(new TrackForNextMatch(holder, data, minmax), new CronTrigger(pingInterval));
			schedulerMap.put("TradeWithMinMaxJob", sf);
//			holder.fetchLiveData(token, allTicks);
		} else {
			throw new RuntimeException("No Account is currently active");
		}

	}

}
