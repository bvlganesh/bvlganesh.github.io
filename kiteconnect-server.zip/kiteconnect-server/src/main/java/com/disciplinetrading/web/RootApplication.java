package com.disciplinetrading.web;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootApplication {
	//this URL is used to keep app alive on Heroku. cron-job configured at https://cron-job.org/en/members/jobs/
	@GetMapping("/")
	public String alive() {
		System.out.println("alive ping");
		return "alive";
	}
	
	@Autowired
	BuildProperties buildProperties;
	@GetMapping("/build")
	public Map<String, String> buildInfo(){
		Map<String, String> info = new HashMap<String, String>();
		info.put("time", LocalDateTime.ofInstant(buildProperties.getTime(), ZoneId.of(ZoneId.SHORT_IDS.get("IST"))).toString());
		info.put("version", buildProperties.getVersion());
		info.put("name", buildProperties.getName());
//		info.put("sysdate", new Date().toString());
//		info.put("timezone", Calendar.getInstance().getTimeZone().getDisplayName());
		return info;
	}
}
