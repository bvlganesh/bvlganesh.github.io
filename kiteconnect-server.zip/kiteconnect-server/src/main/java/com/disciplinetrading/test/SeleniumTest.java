package com.disciplinetrading.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SeleniumTest {
	public static void main(String[] args) throws InterruptedException {
        // declaration and instantiation of objects/variables
		System.setProperty("webdriver.gecko.driver", "F:\\Java\\selenium\\geckodriver.exe");
		openChrome();
    }
	private static void openChrome() throws InterruptedException {
		System.out.println("Debug 1");
		DesiredCapabilities capabilities=DesiredCapabilities.firefox();
		System.out.println("Debug 2");
		capabilities.setCapability("marionette", true);
		FirefoxOptions options = new FirefoxOptions();
		options.setHeadless(true);
		System.out.println("Debug 3");
//		WebDriver driver = new HtmlUnitDriver();
		WebDriver driver = new FirefoxDriver(options);
		System.out.println("Debug 4");
        driver.get("https://kite.trade/connect/login?api_key=ezk7ssacfna3evrz&v=3");
        System.out.println(driver.getTitle());
        
        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[1]/input")).sendKeys("RK0594");
        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[2]/input")).sendKeys("trade1777");
        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[4]/button")).click();
        System.out.println("after 1st password");
        System.out.println(driver.getTitle());
        System.out.println(driver.getCurrentUrl());
        ///html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[2]/div/input
        Thread.sleep(3000);
        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[2]/div/input")).sendKeys("123456");
        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div/div/div[2]/form/div[3]/button")).click();
        Thread.sleep(3000);
        System.out.println("final");
        
        String url = driver.getCurrentUrl();
        System.out.println(url);
        if(url.contains("request_token=")) {
        	System.out.println("TOken:"+ url.split("request_token=")[1].split("&")[0]);
        }
        //quit the browser
        driver.quit();
		
	}
}
