package com.disciplinetrading.test;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.JSONException;
import org.springframework.util.StopWatch;

import com.disciplinetrading.account.Account;
import com.disciplinetrading.account.KiteConnectHolder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Stopwatch;
import com.google.gson.Gson;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;
import com.zerodhatech.models.Instrument;
import com.zerodhatech.models.LTPQuote;
import com.zerodhatech.models.OHLCQuote;
import com.zerodhatech.models.Position;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ConnectionTest {
	public static void main(String[] args) {

//		method1();
		method2();
		System.err.println(System.getProperty("os.name"));
		
	}

	private static void method2() {
		
		
		KiteConnectHolder holder = new KiteConnectHolder();
		holder.initialize();
		Account acnt = holder.getAccounts().get("RK0594");
		try {
			holder.initiateSession(acnt);
//			getHDLC(holder);
//			allInstruments(holder);
			getOrders(holder);

		} catch (KiteException| Exception e) {
			e.printStackTrace();
		}
		
	}

	private static void getOrders(KiteConnectHolder holder) throws JSONException, IOException, KiteException, InterruptedException {
		Gson gs = new Gson();
		StopWatch sw = new StopWatch();
		for(int i=0; i< 60; i++) {
			
			sw.start();
			Map<String, List<Position>> orders = holder.getKiteSdk().getPositions();
			
			sw.stop();
			System.err.println("Time:" + sw.getLastTaskTimeMillis());
			List<Position> netOrder = orders.get("day");
//			List<Position> dayOrder = orders.get("day");
//			System.err.println(gs.toJson(dayOrder));
			System.err.println(netOrder.size());
			Position po = netOrder.get(0);
//			Position po1 = netOrder.get(1);
			log.info("symbol:{}, pnl:{}, price:{}, unrealized:{}", 
					po.tradingSymbol, po.pnl, po.lastPrice, po.unrealised);
//			System.err.println(new Date().toString() + ":::"+po1.tradingSymbol + " ::: "+po1.pnl);
//			log.info("symbol:{}, pnl:{}, price:{}", po1.tradingSymbol, po1.pnl, po1.lastPrice);
			System.err.println(gs.toJson(netOrder.get(0)));
			Thread.sleep(30000);
		}
		//Map<String, List<Position>> orders = holder.getKiteSdk().getPositions();
//		System.err.println(new Gson().toJson(orders.get("net")));
	}

	private static void allInstruments(KiteConnectHolder holder) throws JSONException, IOException, KiteException {
		StopWatch sw = new StopWatch();
		sw.start();
		List<Instrument> all = holder.getKiteSdk().getInstruments();
		new ObjectMapper().writeValue(new File("dump.txt"), all);
		log.info("Size:{}", all.size());
		sw.stop();
		log.info("Timetaken:{}", sw.getTotalTimeSeconds());
		
	}

	private static void getHDLC(KiteConnectHolder holder) {
		
		ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
		Runnable periodicTask = new Runnable() {
			public void run() {
				// Invoke method(s) to do the work
				
				try {
					StopWatch sw = new StopWatch();
					sw.start();
//					Map<String, OHLCQuote> qq = holder.getKiteSdk().getOHLC(new String[] { "10627330" });
					Map<String, LTPQuote> qq = holder.getKiteSdk().getLTP(new String[] { "10627330" });
					sw.stop();
					log.info("tt:" + sw.getTotalTimeMillis());
					log.info(new Gson().toJson(qq));
				} catch (JSONException | IOException | KiteException e) {
					e.printStackTrace();
				} finally {
//					sw.stop();
					
					
				}
				

			}
		};

		executor.scheduleAtFixedRate(periodicTask, 0, 1, TimeUnit.SECONDS);
		
	}

	private static void method1() {
		try {
			KiteConnectHolder holder = new KiteConnectHolder();
			holder.initialize();
			Account acnt = holder.getAccounts().get("RK0594");
			holder.initiateSession(acnt);
			Long token = 2565L;
			StopWatch sw = new StopWatch();
			sw.start();
			Map<String, LTPQuote> q = holder.getKiteSdk().getLTP(new String[] { token.toString(), "408065" });
			sw.stop();
			System.err.println("tt:" + sw.getTotalTimeMillis());
			System.err.println(new Gson().toJson(q));
			sw.start();
			Map<String, OHLCQuote> qq = holder.getKiteSdk().getOHLC(new String[] { token.toString(), "408065" });
			sw.stop();
			System.err.println("tt:" + sw.getTotalTimeMillis());
			System.err.println(new Gson().toJson(qq));
		} catch (IOException | KiteException e) {
			e.printStackTrace();
		}

	}
}
