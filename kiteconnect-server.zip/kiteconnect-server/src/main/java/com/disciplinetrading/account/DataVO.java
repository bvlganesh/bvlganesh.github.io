package com.disciplinetrading.account;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import com.zerodhatech.models.LTPQuote;
import com.zerodhatech.models.Tick;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class DataVO {

//	private final List<Tick> ticks = new ArrayList<>();
//	private final List<LTPQuote> ltpQuotes = new ArrayList<>();
//	public void addTick(Tick tick) {
//		ticks.add(tick);
//	}
//	
//	
//	public void addLTPQuote(LTPQuote quote) {
//		ltpQuotes.add(quote);
//	}
	// below will hold ticks/LTPQuotes per trade/trackingtoken/tokenId
	@Getter(value = AccessLevel.PACKAGE)
	@Setter(value = AccessLevel.NONE)
	private final Map<Long, List<DTTick>> ticks = new HashMap<>();
	@Getter(value = AccessLevel.PACKAGE)
	@Setter(value = AccessLevel.NONE)
	private final Map<Long, List<DTLTPQuote>> ltpQuotes = new HashMap<>();
	@Getter(value = AccessLevel.PACKAGE)
	@Setter(value = AccessLevel.NONE)
	private final Map<Long, List<OrderConfig>> orders = new HashMap<>();
	
	@Getter
	@Setter
	private Double orderTotal = 0d;
	
	@Getter
	@Setter
	private boolean orderPlaced = false;
	
	// below methods should not be accessible outside this package
	void addTick(Tick tick) {
		ticks.putIfAbsent(tick.getInstrumentToken(), new ArrayList<>());
		ticks.get(tick.getInstrumentToken()).add(new DTTick(tick));
	}

	void addLTPQuote(LTPQuote quote) {
		ltpQuotes.putIfAbsent(quote.instrumentToken, new ArrayList<>());
		ltpQuotes.get(quote.instrumentToken).add(new DTLTPQuote(quote));
	}
	
	public void addOrder(OrderConfig order) {
		orders.putIfAbsent(order.getTokenId(), new ArrayList<>());
		orders.get(order.getTokenId()).add(order);
	}

	List<DTTick> ticksById(Long tokenId) {
		return ticks.getOrDefault(tokenId, new ArrayList<>());
	}

	public List<DTLTPQuote> ltpQuotesById(Long tokenId) {
		return ltpQuotes.getOrDefault(tokenId, new ArrayList<>());
	}

	public List<OrderConfig> ordersById(Long tokenId) {
		return orders.getOrDefault(tokenId, new ArrayList<>());
	}
	
	
	void clearLTPQuotes(Long tokenId) {
		ltpQuotes.computeIfPresent(tokenId, (token, list) -> {
			list.clear();
			return list;
		});
	}

	void clearTicks(Long tokenId) {
		ticks.computeIfPresent(tokenId, (token, list) -> {
			list.clear();
			return list;
		});
	}
	
	void clearOrders(Long tokenId) {
		orders.computeIfPresent(tokenId, (token, list) -> {
			list.clear();
			return list;
		});
	}
	public void printOrders() {
		if(CollectionUtils.isEmpty(orders)) {
			log.info("No orders yet");
		} else {
			log.info(String.format("%18s|%4s|%4s|%4s|%16s","TokenSymbol","Type","Price", "Qty","OrderTime"));
			log.info("***********************************************************");
			for(Long token : orders.keySet()) {
				for(OrderConfig order: orders.get(token)) {
					log.info(String.format("%18s|%4s|%4s|%4s|%16s", order.tradingsymbol, order.transactionType, order.price, order.quantity, order.getTime()));
				}
			}
			log.info("----------------------------------------------------------");
		}
	}
	public List<OrderConfig> ordersByTokenSymbol(String tokenSymbol){
		List<OrderConfig> existingOrders = new ArrayList<>();
		for(Long tokenIds : orders.keySet()) {
			for(OrderConfig order : orders.get(tokenIds)) {
				if(tokenSymbol.equalsIgnoreCase(order.tradingsymbol)) {
					existingOrders.add(order);
					break;
				}
			}
		}
		return existingOrders;
	}
	public Set<Long> tradeIdsOfOrders(){
		return orders.keySet();
	}
}
