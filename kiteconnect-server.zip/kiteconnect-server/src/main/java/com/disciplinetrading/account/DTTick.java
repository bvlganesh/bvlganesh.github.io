package com.disciplinetrading.account;

import java.util.Date;

import com.zerodhatech.models.Tick;

import lombok.Getter;

public class DTTick{
	@Getter
	private Tick tick;
	@Getter
	private Date time;
	public DTTick(Tick tick) {
		this.tick = tick;
		this.time = new Date();
	}
}
