package com.disciplinetrading.account;

import java.util.Date;

import com.zerodhatech.models.OrderParams;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class OrderConfig extends OrderParams {
	private Long tokenId;
	private Date time = new Date();
}
