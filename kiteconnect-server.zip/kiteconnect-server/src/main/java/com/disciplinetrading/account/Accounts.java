package com.disciplinetrading.account;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Accounts {
	List<Account> accounts;
	
	
}
