package com.disciplinetrading.account;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.zerodhatech.kiteconnect.KiteConnect;
import com.zerodhatech.kiteconnect.kitehttp.SessionExpiryHook;
import com.zerodhatech.kiteconnect.kitehttp.exceptions.KiteException;
import com.zerodhatech.models.Instrument;
import com.zerodhatech.models.Tick;
import com.zerodhatech.models.User;
import com.zerodhatech.ticker.KiteTicker;
import com.zerodhatech.ticker.OnConnect;
import com.zerodhatech.ticker.OnDisconnect;
import com.zerodhatech.ticker.OnTicks;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class KiteConnectHolder {
	private static final Map<String, TokenConfig> tokenMap = new HashMap<>();
	static {
		tokenMap.put("NIFTY", new TokenConfig(256265L, "NIFTY", 50L ));
		tokenMap.put("BANKNIFTY", new TokenConfig(260105L, "BANKNIFTY", 100L));
	}
	public Long getKiteTokenId() {
		return tokenMap.get(currentAccount().getTokenGroup()).getTokenId();
	}
	public Long getStepValue() {
		return tokenMap.get(currentAccount().getTokenGroup()).getStepValue();
	}
	@PostConstruct//should get executed only once
	public void initialize() {
		try {
			log.info("Initializing accounts");
			List<Account> preaccounts = new Gson()
					.fromJson(new FileReader("src/main/resources/static/accounts/accounts.json"), Accounts.class)
					.getAccounts();
			accounts = preaccounts.stream().collect(Collectors.toMap(Account::getId, y -> y));
			
			
		} catch (JsonSyntaxException | JsonIOException | FileNotFoundException e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Getter
	@Setter(value = AccessLevel.PRIVATE)
	private KiteConnect kiteSdk;
	@Getter(value = AccessLevel.PUBLIC)
	private Map<String, Account> accounts;
	@Getter(value = AccessLevel.PUBLIC)
	private Map<String, Instrument> instruments;
	public void resetSession() {
		kiteSdk = null;
	}

//	@Bean
//	@Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
	public void initiateSession(Account acnt) throws IOException, KiteException {
		log.info("Initiating session for :{}", acnt.getId());
		kiteSdk = new KiteConnect(acnt.getApiKey());

		kiteSdk.setUserId(acnt.getId());
		fetchUser(kiteSdk, acnt);

		kiteSdk.setSessionExpiryHook(new SessionExpiryHook() {
			@Override
			public void sessionExpired() {
				log.info("session expired");
			}
		});
	}

	private User fetchUser(KiteConnect kiteSdk, Account accountConfig) throws IOException, KiteException {
		ObjectMapper mapper = new ObjectMapper();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		User userModel = null;
		File userModelFile = new File(accountConfig.getId() + "-userconfig-" + sdf.format(new Date()) + ".txt");
		if (userModelFile.exists()) {
			log.info("Reading from file for account:{}", accountConfig.getId());
			userModel = mapper.readValue(userModelFile, User.class);
			kiteSdk.setAccessToken(userModel.accessToken);
			kiteSdk.setPublicToken(userModel.publicToken);
		} else {
			log.info("Establishing new session for:{}", accountConfig.getId());
			userModel = kiteSdk.generateSession(accountConfig.getRequestToken(), accountConfig.getApiSecret());
			log.info("AccessToken:{};PublickToken:{}", userModel.accessToken, userModel.publicToken);
			kiteSdk.setAccessToken(userModel.accessToken);
			kiteSdk.setPublicToken(userModel.publicToken);
			accountConfig.setLastSessionCreated(Calendar.getInstance().getTime());
			mapper.writeValue(userModelFile, userModel);
		}

		return userModel;
	}

	/**
	 * Returns the account matching with current KiteConnect session. Returns empty
	 * if none found.
	 * 
	 * @return
	 */
	/*
	 * @Bean
	 * 
	 * @RequestScope public Optional<Account> getCurrentAccount() { if (kiteSdk ==
	 * null) { return Optional.empty(); } return
	 * Optional.of(accounts.get(kiteSdk.getUserId())); }
	 */

	public void addAccount(Account acnt) {
		accounts.put(acnt.getId(), acnt);
	}

	public Boolean existingAccount(String accountId) {
		return accounts.containsKey(accountId);

	}

	public Account currentAccount() {
		return accounts.get(kiteSdk.getUserId());
	}

	private KiteTicker tickerProvider;

	public void unsubscribeAndDisc(Long token) {
		log.info("Unscribe and disconnect for token:{}", token);
		tickerProvider.unsubscribe(new ArrayList<Long>(Arrays.asList(token)));
		tickerProvider.disconnect();
	}

	public void fetchLiveData(Long token, List<Tick> allTicks) throws KiteException {
		ArrayList<Long> tokens = new ArrayList<Long>(Arrays.asList(token));
		fetchLiveDataCallBack(tokens, allTicks::addAll);
	}

	public void fetchLiveData(ArrayList<Long> tokens, List<Tick> allTicks) throws KiteException {
		fetchLiveDataCallBack(tokens, allTicks::addAll);
	}

	public void fetchLiveDataCallBack(ArrayList<Long> tokens, Consumer<ArrayList<Tick>> callback) throws KiteException {

		tickerProvider = new KiteTicker(kiteSdk.getAccessToken(), kiteSdk.getApiKey());

		tickerProvider.setOnConnectedListener(new OnConnect() {
			@Override
			public void onConnected() {
				/**
				 * Subscribe ticks for token. By default, all tokens are subscribed for
				 * modeQuote.
				 */

//;				ArrayList<Long> tokens = (ArrayList<Long>) configuration.getTokensValues();
				log.info("setOnConnectedListener:tokens:{}", tokens);
				tickerProvider.subscribe(tokens);
				tickerProvider.setMode(tokens, "full");
			}
		});

		tickerProvider.setOnDisconnectedListener(new OnDisconnect() {
			@Override
			public void onDisconnected() {
				// your code goes here
//				ArrayList<Long> tokens = (ArrayList<Long>) configuration.getTokensValues();
//				tickerProvider.setMode(tokens, "full");

				// Unsubscribe for a token.
				tickerProvider.unsubscribe(tokens);

				log.info("disconnected and unscubscribed");
			}
		});
//		kiteSdk.getOHLC(instruments)

		tickerProvider.setOnTickerArrivalListener(new OnTicks() {
			@Override
			public void onTicks(ArrayList<Tick> ticks) {
//            	logger.debug("Ticks received: " + ticks.size());
				callback.accept(ticks);
				// disconnect after receiving atleast one tick
				if (!ticks.isEmpty()) {
					tickerProvider.disconnect();
				}
			}

		});

		tickerProvider.setTryReconnection(true);
		// maximum retries and should be greater than 0
		tickerProvider.setMaximumRetries(2);
		// set maximum retry interval in seconds
		tickerProvider.setMaximumRetryInterval(30);

		/**
		 * connects to com.zerodhatech.com.zerodhatech.ticker server for getting live
		 * quotes
		 */
		tickerProvider.connect();

		/**
		 * You can check, if websocket connection is open or not using the following
		 * method.
		 */
//        boolean isConnected = tickerProvider.isConnectionOpen();
//        System.out.println("isConnected:" + isConnected + " at " + sdf.format(new Date()));
		// disconnect is triggered after receiving atleast one tick

	}

}
