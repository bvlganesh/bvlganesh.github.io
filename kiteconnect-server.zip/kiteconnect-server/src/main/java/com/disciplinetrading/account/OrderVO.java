package com.disciplinetrading.account;

import com.zerodhatech.kiteconnect.utils.Constants;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter(value = AccessLevel.NONE)
public class OrderVO {
	private Long tokenId;
	private String symbol;
	private String type;
	private Integer quantity;
	private String price;
	private final String orderType = Constants.ORDER_TYPE_MARKET;
	private final String product = Constants.PRODUCT_MIS;
	private final String exchange = Constants.EXCHANGE_NFO;
	private final String validity = Constants.VALIDITY_DAY;
	
	private final String tag = "MyTag123";
	/*
	 orderParams.quantity = token.getQuantity();
		orderParams.orderType = Constants.ORDER_TYPE_MARKET;
		orderParams.tradingsymbol = token.getSymbol();
		orderParams.product = Constants.PRODUCT_MIS;
		orderParams.exchange = Constants.EXCHANGE_NFO;
		orderParams.transactionType = orderType;// Constants.TRANSACTION_TYPE_BUY;// SELL
		orderParams.validity = Constants.VALIDITY_DAY;

		orderParams.disclosedQuantity = token.getQuantity();

		orderParams.tag = "MyTag123";
	 */
}
