package com.disciplinetrading.account;

import java.util.Date;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Account {
	@NotNull
	private String id;
	private String apiSecret;
	
	private String apiKey;
	@Getter(value = AccessLevel.PRIVATE)
	private String mode = "full";
	private Integer pingInterval = 60;
	private Boolean startatzero = false;
	@NotNull
	private String tokenGroup;
	private String requestToken;
	private Date lastSessionCreated;
	
	
}
