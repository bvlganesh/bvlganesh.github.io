package com.disciplinetrading.account;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PRIVATE)
public class TokenConfig {
	private Long tokenId;
	private String tokenSymbol;
	private Long stepValue;
}
