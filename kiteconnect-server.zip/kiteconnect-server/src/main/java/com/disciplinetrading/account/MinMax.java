package com.disciplinetrading.account;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Collections;
import java.util.List;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;


@Getter(value = AccessLevel.PUBLIC)
@ToString
@Slf4j
public class MinMax {

	private Double min;
	private Double max;
	
	public MinMax(Double min, Double max) {
		this.min = min;
		this.max = max;
	}
	
	public MinMax(List<Double> values, Long stepValue) {
		this(values, false, stepValue);
	}
	public MinMax(List<Double> values, boolean round, Long stepValue) {
		this.min = Collections.min(values);
		this.max = Collections.max(values);
//		DecimalFormat df = new DecimalFormat();
//		df.scal
		if(round) {
			min = nearestStepValue(min, stepValue);
			max = nearestStepValue(max, stepValue);
		}
		if(min.doubleValue() == max.doubleValue()) {
			//if both min max are same, reduce min by 100 to avoid accidental triggers
			log.info("Reducing min value by 100 . {}", min - stepValue);
			this.min = this.min - stepValue;
		}
	}
	private Double nearestStepValue(Double min, Long stepValue) {
		int reminder = (int) (min.longValue() % stepValue);
		long newValue = 0;
		if(reminder < stepValue/2) {
			newValue = (new BigDecimal( min / stepValue).longValue()) * stepValue;
		} else {
			newValue = new BigDecimal( min / stepValue).longValue() * stepValue + stepValue ;
		}
		return new BigDecimal(newValue).round(new MathContext(0)).doubleValue();
	}

	public Long minLong() {
		return min.longValue();
	}
	public Long maxLong() {
		return max.longValue();
	}
}
