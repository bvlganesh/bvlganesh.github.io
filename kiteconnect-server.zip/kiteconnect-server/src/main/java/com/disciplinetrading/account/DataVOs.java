package com.disciplinetrading.account;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zerodhatech.models.LTPQuote;
import com.zerodhatech.models.Tick;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DataVOs {
//	private Map<String,>
	@Getter(value = AccessLevel.PRIVATE)
	@Setter(value = AccessLevel.NONE)
	private final Map<String, DataVO> values = new HashMap<>();

	public void putData(String accountId, DataVO data) {
		// avoids overriding values during runtime
		DataVO existingValue = values.putIfAbsent(accountId, data);
		if (existingValue != null) {
			log.warn("Overriding existing data failed for account:{}", accountId);
		}
	}

	public DataVO getData(String accountId) {
		values.putIfAbsent(accountId, new DataVO());
		return values.get(accountId);
	}

	public void addLTPQuote(String accountId, LTPQuote quote) {
		getData(accountId).addLTPQuote(quote);
	}

	public void addTick(String accountId, Tick tick) {
		getData(accountId).addTick(tick);
	}

	public void clearTicksByToken(String accountId, Long token) {
		log.debug("clearTicksByToken for account:{}", accountId);
		getData(accountId).clearTicks(token);
	}

	public void clearLTPQuotesByToken(String accountId, Long token) {
		log.debug("clearLTPQuotesByToken for account:{}", accountId);
		getData(accountId).clearLTPQuotes(token);
	}

	public void clearAll(String accountId) {
		log.debug("Cleared DataVO for account:{}", accountId);
		values.put(accountId, new DataVO());
	}

	public MinMax computeMinMaxFromTicks(String accountId, Long tokenId, boolean reset, Long stepValue) {
		List<Double> ltps = new ArrayList<>();
		DataVO data = values.get(accountId);
		for (DTTick tick : data.ticksById(tokenId)) {
			ltps.add(tick.getTick().getLastTradedPrice());
		}
		if (reset) {
			values.get(accountId).clearTicks(tokenId);
		}
//		return computeMinMax(ltps);
		return new MinMax(ltps, true, stepValue);
	}

	public MinMax computeMinMaxFromLTPQuotes(String accountId, Long tokenId, boolean reset, Long stepValue) {
		List<Double> lastPrices = new ArrayList<>();
		DataVO data = values.get(accountId);
		for (DTLTPQuote quote : data.ltpQuotesById(tokenId)) {
			lastPrices.add(quote.getQuote().lastPrice);
		}

		if (reset) {
			values.get(accountId).clearLTPQuotes(tokenId);
		}
//		return computeMinMax(lastPrices);
		return new MinMax(lastPrices, true, stepValue);
	}

	private MinMax computeMinMax(List<Double> allTicks) {
//		Double min = 0d, max = 0d;
//		for (Double tick : allTicks) {
//			if (min > tick || min == 0d) {
//				min = tick;
//			}
//			if (max < tick || max == 0d) {
//				max = tick;
//			}
//		}
		Double min = Collections.min(allTicks);
		Double max = Collections.max(allTicks);
		// round to nearest 100
		min = ((int) min.doubleValue() / 100) * 100.0;
		max = ((int) max.doubleValue() / 100) * 100.0;
		log.info("Min:{}, Max:{}", min, max);
		return new MinMax(min, max);
	}

}
