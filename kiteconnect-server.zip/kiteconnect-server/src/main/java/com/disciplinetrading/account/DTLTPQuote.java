package com.disciplinetrading.account;

import java.util.Date;

import com.zerodhatech.models.LTPQuote;

import lombok.Getter;

public class DTLTPQuote {
	@Getter
	private LTPQuote quote;
	@Getter
	private Date time;
	public DTLTPQuote(LTPQuote quote) {
		this.quote = quote;
		this.time = new Date();
	}
}
