package com.disciplinetrading.account;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.apache.commons.io.FileUtils;
import org.springframework.util.StopWatch;

import com.zerodhatech.models.Instrument;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AllInstruments {
//	private static 
	private static Map<String, Instrument> instrumentsBySymbol = new HashMap<>();
	private static Map<String, Instrument> instrumentsById = new HashMap<>();
	private static Set<Instrument> allInstruments = new HashSet<>();
	static {
		try {
			StopWatch sw = new StopWatch();
			sw.start();
			List<String> lines = FileUtils.readLines(new File("src/main/resources/static/instruments-new"), "UTF-8");
			lines.stream().forEach(line -> {
				String[] lineArr = line.split(",");
				if (lineArr.length > 5) {
					try {

						Instrument newInstrument = new Instrument();
						newInstrument.setInstrument_token(Long.valueOf(lineArr[0]));
						newInstrument.setExchange_token(Long.valueOf(lineArr[1]));
						newInstrument.setTradingsymbol(lineArr[2]);
						newInstrument.setExchange(lineArr[11]);
						newInstrument.setStrike(lineArr[6]);
						newInstrument.setLot_size(Integer.valueOf(lineArr[8]));
						allInstruments.add(newInstrument);
						instrumentsBySymbol.put(lineArr[2], newInstrument);
						instrumentsById.put(lineArr[0], newInstrument);

					} catch (Exception e) {
						System.err.println("Failed for token:" + line);
					}
				}
			});
			sw.stop();
			log.info("Time taken for reading AllInstruments:{}", sw.getTotalTimeMillis());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Instrument byId(String id) {
		return instrumentsById.get(id);
	}

	public static Instrument bySymbol(String symbol) {
		return instrumentsBySymbol.get(symbol);
	}

	public static Set<Instrument> matchingInstruments(@NotNull String exchange, Double upperStrikePrice,
			Double lowerStrikePrice, @NotNull String symbolRegex) {
		Set<Instrument> matchingInstruments = allInstruments.parallelStream()
				.filter(instrument -> exchange.equalsIgnoreCase(instrument.getExchange())
						&& instrument.getTradingsymbol() != null
						&& instrument.getTradingsymbol().startsWith(symbolRegex)
						&& (Double.valueOf(instrument.getStrike()) > lowerStrikePrice
								&& Double.valueOf(instrument.getStrike()) < upperStrikePrice))
				.collect(Collectors.toSet());

		log.info(
				"matchingInstruments for exchange:{}, upper strikeprice:{}, lower strikeprice:{}, symbol pattern:{} are:{}",
				exchange, upperStrikePrice, lowerStrikePrice, symbolRegex, matchingInstruments.size());
		return matchingInstruments;
	}

}
