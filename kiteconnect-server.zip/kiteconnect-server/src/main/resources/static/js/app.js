var tradingApp = angular.module("tradingApp", [ "ngRoute" ]);
tradingApp.config(function($routeProvider) {

	// $urlRouterProvider.otherwise('/config');

	$routeProvider.when('/trade', {
		templateUrl : './trade.html',
		controller : 'tradingController'
	}).when('/config', {
		templateUrl : './config.html',
		controller : 'configController'
	}).otherwise({
		redirectTo : '/config'
	});

	//
});
tradingApp.controller('configController', function($scope, $http, $location) {
	$scope.$watch('selectedAccount', function() {
		if ($scope.selectedAccount) {
//			console.log($scope.selectedAccount.apiKey);
			$scope.tokenUrl = 'https://kite.trade/connect/login?api_key='
					+ $scope.selectedAccount.apiKey + '&v=3';
		}
	})
	$scope.updateTokenGroup = function(tokenGroupSelected) {
		/*
		 * if($scope.tokenGroupSelected){ $scope.selectedAccount.tokenGroup =
		 * $scope.tokenGroups[1].value; } else {
		 * $scope.selectedAccount.tokenGroup = $scope.tokenGroups[0].value; }
		 */
		console.log($scope.tokenGroups);
		if (tokenGroupSelected) {
			$scope.selectedAccount.tokenGroup = $scope.tokenGroups[1].key;
		} else {
			$scope.selectedAccount.tokenGroup = $scope.tokenGroups[0].key;
		}
	}
	$scope.updateTokenGroupValue = function(selAccount) {
		if (selAccount.tokenGroup === $scope.tokenGroups[0].key) {
			$scope.tokenGroupSelected = false;
		} else if (selAccount.tokenGroup === $scope.tokenGroups[0].key) {
			$scope.tokenGroupSelected = true;
		}
	}
	function init() {
		$scope.accounts = {};
		// $scope.errors = [];
		$scope.errorMsg = '';
		$scope.tokenGroupSelected = true;
		$scope.operation = '';
		$http.get("/algo4/accounts").then(
				function(data) {
					$scope.accounts = data.data.data;
					$scope.selectedAccount = data.data.data[Object
							.keys(data.data.data)[0]];
					console.log($scope.selectedAccount);
					$scope.errorMsg = '';
				}, function(error) {
					$scope.accounts = {};
					$scope.errorMsg = error.data.message;

				});
		$http.get("/algo4/config").then(function(data) {
			$scope.tokenGroups = data.data.data;
		}, function(error) {
			$scope.errorMsg = error.data.message;
		})
	}
	$scope.updateField = function(selectedAccount, selectedItem) {
		console.log(selectedItem);
		$scope.selectedAccount.tokenGroup = selectedItem.name;
		return true;
	}
	$scope.addAccount = function() {
		$http({
			url : '/algo4/account/update',
			method : "POST",
			data : $scope.selectedAccount

		}).then(function(response) {
			console.log(response.data);
		}, function(response) { // optional
			console.log("Failed:" + response);
		});
	}
	$scope.shutdown = function(){
		$scope.errorMsg = '';
		$http({
			url : '/algo4/shutdown',
			method : "GET",
		}).then(function successCallback(response){
			$scope.errorMsg = response.data.data;
		}, function errorCallback(response){
			$scope.errorMsg = response.data.data;
		})
	}
	$scope.tradeNow = function() {
		$scope.errorMsg = '';

		$http({
			url : '/algo4/account/connect',
			method : "POST",
			data : $scope.selectedAccount

		}).then(function successCallback(response) {
			console.log(response);
			if (response.data.status != 'SUCCESS') {
				$scope.errorMsg = response.data.message;
				// $location.path("/trade");
			} else {
				$scope.errorMsg = '';
				$location.path("/trade");
			}

		}, function errorCallback(response) {
			console.error(response);
			$scope.errorMsg = response.data.message;
		});

	}
	init();

});

tradingApp.controller('tradingController', function($scope, $http, $location) {

	function init() {

		/*
		 * $scope.upper = 30000; $scope.lower = 28000;
		 */
		// $scope.upper = 10400;
		// $scope.lower = 10200;
		$http.get('/algo4/tokens').then(function(data) {
			var allTrades = data.data;
			/*
			 * angular.forEach(allTrades, function(trade){ if(trade.symbol) })
			 */
			// $scope.trades = data.data.tokens;
			$scope.calls = data.data.data.calls.tokens;
			$scope.puts = data.data.data.puts.tokens;
			/*
			 * angular.forEach($scope.trades, function(trade) { if
			 * (trade.symbol.endsWith("CE")) { // trade.isCall = true;
			 * $scope.calls.push(trade); } else { // trade.isCall = false;
			 * $scope.puts.push(trade); } })
			 */

			// console.log($scope.trades)
		});
		$http.get('/algo4/activeaccount').then(function(data) {
			// console.error(data.data.data.id);
			$scope.currentUser = data.data.data.id;
		});
	}
	$scope.clear = function(data) {

		angular.forEach(data, function(d) {
			d.selected = false;
		});

	}
	// $scope.selectedCalls = [];
	// $scope.selectedPuts = [];
	// $scope.selectedTrades = [];
	/*
	 * $scope.removeSelected = function(selectedTrade, type){ var position = -1;
	 * angular.forEach($scope.selectedTrades, function(trade,idx){
	 * if(trade.symbol === selectedTrade.symbol){ position = idx; } });
	 * $scope.selectedTrades.splice(position); angular.forEach($scope.calls,
	 * function(call){ if(call.symbol === selectedTrade.symbol){ call.selected =
	 * false; } }); angular.forEach($scope.puts, function(put){ if(put.symbol
	 * === selectedTrade.symbol){ put.selected = false; } }); }
	 */
	/*
	 * $scope.addSelected = function(selectedTrade, type){ var alreadySelected =
	 * false;
	 * 
	 * angular.forEach($scope.selectedTrades, function(trade){ if(trade.symbol
	 * === selectedTrade.symbol){ alreadySelected = true; return false; } })
	 * if(!alreadySelected){ $scope.selectedTrades.push(selectedTrade); }
	 * selectedTrade.selected = true; }
	 */
	$scope.placeOrder = function(type) {
		var selectedTokens = [];

		angular.forEach($scope.calls, function(token) {
			if (token.selected) {
				selectedTokens.push(token);
			}
		});
		angular.forEach($scope.puts, function(token) {
			if (token.selected) {
				selectedTokens.push(token);
			}
		});
		$scope.errorMsg = '';
		$http({
			url : '/algo4/order/' + type,
			method : "POST",
			data : {
				"tokens" : selectedTokens
			}
		}).then(function(response) {
			$scope.errorMsg = '';
			console.log(response);
		}, function(response) { // optional
			console.log("Failed:" + response);
			$scope.errorMsg = response;
		});

	}
	$scope.gotoConfig = function() {
		$location.path("/config");
	}
	$scope.shutdown = function(){
		$scope.errorMsg = '';
		$http({
			url : '/algo4/shutdown',
			method : "GET",
		}).then(function successCallback(response){
			$scope.errorMsg = response.data.data;
		}, function errorCallback(response){
			$scope.errorMsg = response.data.data;
		})
	}
	init();

})