package com.disciplinetrading.algotrading.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.CollectionUtils;

import com.disciplinetrading.account.DataVO;
import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.account.OrderConfig;
import com.disciplinetrading.algo4.cron.jobs.TradeWithMinMaxJob;
import com.disciplinetrading.algotrading.trading.Algo4Test;
import com.disciplinetrading.algotrading.trading.Algo4Tests;
import com.disciplinetrading.algotrading.trading.Assertions;
import com.disciplinetrading.algotrading.trading.Counts;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.zerodhatech.kiteconnect.utils.Constants;
import com.zerodhatech.models.LTPQuote;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class TestTrading {
	private final DataVOs data = new DataVOs();

//	@Autowired
//	CronConfiguration config;
	
	@Autowired
	Gson gson;

//	@Value("${accountId}")
//	private String accountId;

	@Test
	void testBankNifty() throws JsonSyntaxException, JsonIOException, FileNotFoundException, JsonProcessingException {
//		config.initialize();
		String accountId = "RK0594";
		Algo4Tests tests = gson.fromJson(new FileReader("src/test/resources/tradingBankNiftyTests.json"), Algo4Tests.class);
		log.info("Trading Test cases count:{}", tests.getTestInputs().size());
//		System.err.println(tests.getTestInputs().get(0).getMinMax());
		for (Algo4Test test : tests.getTestInputs()) {
			log.info(">>>>>>>>>>>>>>>Scenario:{}", test.getTestcase());
			data.clearAll(accountId);
			MinMax minmaxInput =  test.getMinMax();
			TradeWithMinMaxJob job = new TradeWithMinMaxJob(null, data, minmaxInput);
			for(LTPQuote quote : test.getQuotes()) {
				job.evaluateQuote(quote, accountId, "BANKNIFTY", 100L);
			}
//			System.err.println(gson.toJson(data.getData(tokenId.toString())));	
			assertData(data.getData(accountId), test.getAssertions(),job.getMinmax());
		}
		
	}

	
	@Test
	void testNifty() throws JsonSyntaxException, JsonIOException, FileNotFoundException, JsonProcessingException {
//		config.initialize();
		String accountId = "RK0594";
		Algo4Tests tests = gson.fromJson(new FileReader("src/test/resources/tradingNiftyTests.json"), Algo4Tests.class);
		log.info("Trading Test cases count:{}", tests.getTestInputs().size());
//		System.err.println(tests.getTestInputs().get(0).getMinMax());
		for (Algo4Test test : tests.getTestInputs()) {
			log.info(">>>>>>>>>>>>>>>Scenario:{}", test.getTestcase());
			data.clearAll(accountId);
			MinMax minmaxInput =  test.getMinMax();
			TradeWithMinMaxJob job = new TradeWithMinMaxJob(null, data, minmaxInput);
			for(LTPQuote quote : test.getQuotes()) {
				job.evaluateQuote(quote, accountId, "NIFTY", 50L);
			}
//			System.err.println(gson.toJson(data.getData(tokenId.toString())));	
			assertData(data.getData(accountId), test.getAssertions(),job.getMinmax());
		}
		
	}
	
	private void assertData(DataVO data, Assertions assertions, MinMax actualMinMax) {
		if(CollectionUtils.isEmpty(assertions.getOrders())) {
			assertTrue(!data.isOrderPlaced(), "Orders for assertions are empty but orders are placed:" + assertions);
		}
		
		Counts actualCounts = new Counts();
		
		Set<Long> tokenIds = data.tradeIdsOfOrders();
		for(Long tokenId : tokenIds) {
			List<OrderConfig> actualOrders = data.ordersById(tokenId);
			actualOrders.stream().forEach(aorder -> {
				if(Constants.TRANSACTION_TYPE_BUY.equalsIgnoreCase(aorder.transactionType)) {
					actualCounts.setBuy(actualCounts.getBuy() + 1);
				}
				if(Constants.TRANSACTION_TYPE_SELL.equalsIgnoreCase(aorder.transactionType)) {
					actualCounts.setSell(actualCounts.getSell() + 1);
				}
			});
		}
		Counts expectedCounts = assertions.getCounts();
		assertEquals(expectedCounts.getBuy(), actualCounts.getBuy(), "Number of Buy orders not matched");
		assertEquals(expectedCounts.getSell(), actualCounts.getSell(), "Number of Sell orders not matched" );
		
		MinMax expectedMinMax = assertions.getMinMax();
		assertEquals(expectedMinMax.getMin(), actualMinMax.getMin(), "Min value didnot match");
		assertEquals(expectedMinMax.getMax(), actualMinMax.getMax(), "Max value didnot match");
		
		for(Long tokenId : assertions.getOrders().keySet()) {
			List<OrderConfig> expectedOrders = assertions.getOrders().get(tokenId);
			List<OrderConfig> actual = data.ordersById(tokenId);
			for(OrderConfig expected : expectedOrders) {
				assertTrue(hasOrder(actual, expected), "Order not present:" + expected.tradingsymbol);
			}
		}
	}
	private boolean hasOrder(List<OrderConfig> list, OrderConfig input) {
		boolean hasOrder = false;
		
		for(OrderConfig order: list) {
			if(order.getTokenId().equals(input.getTokenId())
					&& order.transactionType.equalsIgnoreCase(input.transactionType)
					&& order.tradingsymbol.equalsIgnoreCase(input.tradingsymbol)
					&& order.price.equals(input.price)
					) {
				hasOrder = true;
				break;
			}
		}
		return hasOrder;
	}
	
}
