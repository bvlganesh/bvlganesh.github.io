package com.disciplinetrading.algotrading.tracking;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Assertions {
	private Double min;
	private Double max;
	
}
