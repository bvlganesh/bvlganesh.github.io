package com.disciplinetrading.algotrading.trading;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Counts {
	Long buy = 0L;
	Long sell = 0L;
}
