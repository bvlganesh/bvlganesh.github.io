package com.disciplinetrading.algotrading.trading;

import java.util.List;
import java.util.Map;

import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.account.OrderConfig;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Assertions {
	Map<Long, List<OrderConfig>> orders;
	Counts counts;
	MinMax minMax;
	
}
