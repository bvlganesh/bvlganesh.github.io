package com.disciplinetrading.algotrading.service;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.disciplinetrading.account.DataVOs;
import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.algotrading.tracking.Algo4Test;
import com.disciplinetrading.algotrading.tracking.Algo4Tests;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class TestTracking {
	private final DataVOs data = new DataVOs();

	@Test
	void test() throws JsonSyntaxException, JsonIOException, FileNotFoundException {
//		config.initialize();
		String accountId = "RK0594";
		Algo4Tests tests = new Gson().fromJson(new FileReader("src/test/resources/trackingTests.json"), Algo4Tests.class);
		log.info("Tracking Test cases count:{}", tests.getTestInputs().size());

		for (Algo4Test test : tests.getTestInputs()) {
			data.clearAll(accountId);
			log.info("Testcase id:{}", test.getTestcaseId());
			test.getQuotes().forEach(quote -> {
				data.addLTPQuote(accountId, quote);
			});

			MinMax minmax = data.computeMinMaxFromLTPQuotes(accountId, test.getInstrumentToken(), false, 100L);
			assertEquals(minmax.getMax(), test.getAssertions().getMax(), "Max value doesnt match:");
			assertEquals(minmax.getMin(), test.getAssertions().getMin(), "Min value doesnt match:");
		}
	}

}
