package com.disciplinetrading.algotrading.trading;

import java.util.List;
import java.util.Map;

import com.disciplinetrading.account.MinMax;
import com.disciplinetrading.account.OrderConfig;
import com.google.gson.annotations.SerializedName;
import com.zerodhatech.models.LTPQuote;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Algo4Test {
	Long testcase;
	List<LTPQuote> quotes;
	Assertions assertions;
	@SerializedName("instrument_token")
    Long instrumentToken;
	MinMax minMax;
	Map<Long, List<OrderConfig>> orders;
}
