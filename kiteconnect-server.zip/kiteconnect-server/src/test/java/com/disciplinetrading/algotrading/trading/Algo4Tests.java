package com.disciplinetrading.algotrading.trading;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class Algo4Tests {
	@Getter
	@Setter
	List<Algo4Test> testInputs;
}
